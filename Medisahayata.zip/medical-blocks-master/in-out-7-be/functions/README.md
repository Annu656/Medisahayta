# Backend APIs for Medical-Blocks

To be deployed as a firebase function
