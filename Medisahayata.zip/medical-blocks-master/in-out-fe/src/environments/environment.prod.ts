export const environment = {
  apiUrl:
    'https://us-central1-in-out-7-298618.cloudfunctions.net/webApi/api/v1/',
  firebaseConfig: {
    apiKey: 'AIzaSyAo_ftC8lT1RWECnOMLDEzFzaw2o9kanCE',
    authDomain: 'in-out-7-298618.firebaseapp.com',
    projectId: 'in-out-7-298618',
    storageBucket: 'in-out-7-298618.appspot.com',
    messagingSenderId: '597095722436',
    appId: '1:597095722436:web:b80386c4e152caed3f8891',
  },
  hospitalRedirectUrl: 'https://in-out-7-298618.web.app/hospital/login',
  production: true,
};
