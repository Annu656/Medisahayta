export interface ClientDataObj {
  challenge: string;
  origin: string;
  type: string;
}
