import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-h-dash',
  templateUrl: './h-dash.component.html',
  styleUrls: ['./h-dash.component.css']
})
export class HDashComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
